package control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.Types;

/**
 *En este archivo las funciones fueron diseñadas para conseguir IDs de ciertas tablas.
 */
public class Consult {
     public static int getAnimalId(String p_animal) {
        try {
            SysConexion con = new SysConexion();

            Connection connection;
            connection = con.obtConexion();
            CallableStatement callableStatement;
            callableStatement = connection.prepareCall("{call getAnimalId(?, ?)}");
            callableStatement.setString(1, p_animal);
            callableStatement.registerOutParameter(2, Types.INTEGER); // Registro del parámetro de salida
            callableStatement.execute();

            int idReturned = callableStatement.getInt(2); // Obtén el valor del parámetro de salida

            callableStatement.close();
            connection.close();

            return idReturned;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            return -1;
        }
    }


    
    public static int getRaceId(String p_race) {
        try {
            SysConexion con = new SysConexion();

            Connection connection;
            connection = con.obtConexion();
            CallableStatement callableStatement;
            callableStatement = connection.prepareCall("{call getRaceId(?, ?)}");
            callableStatement.setString(1, p_race);
            callableStatement.registerOutParameter(2, Types.INTEGER); // Registro del parámetro de salida
            callableStatement.execute();

            int idReturned = callableStatement.getInt(2); 

            callableStatement.close();
            connection.close();

            return idReturned;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Race: " + e.getMessage());
            return -1;
        }
    }

    
    public static int getEaseId(String p_ease) {
        try {
            SysConexion con = new SysConexion();

            Connection connection; 
            connection = con.obtConexion();
            CallableStatement callableStatement;
            callableStatement = connection.prepareCall("{call getEaseId(?, ?)}");
            callableStatement.setString(1, p_ease);
            callableStatement.registerOutParameter(2, Types.INTEGER); // Registro del parámetro de salida
            callableStatement.execute();

            int idReturned = callableStatement.getInt(2); 

            callableStatement.close();
            connection.close();

            return idReturned;

        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "error Ease: " + e);
            return -1;
        }
    }

    
    public static int getStatusId(String p_status) {
        try {
            SysConexion con = new SysConexion();

            Connection connection; 
            connection = con.obtConexion();
            CallableStatement callableStatement;
            callableStatement = connection.prepareCall("{call getStatusId(?, ?)}");
            callableStatement.setString(1, p_status);
            callableStatement.registerOutParameter(2, Types.INTEGER); // Registro del parámetro de salida
            callableStatement.execute();

            int idReturned = callableStatement.getInt(2); 

            callableStatement.close();
            connection.close();

            return idReturned;

        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "error: " + e);
            return -1;
        }
    }

    
    public static int getEnergyId(String p_energy) {
        try {
            SysConexion con = new SysConexion();

            Connection connection; 
            connection = con.obtConexion();
            CallableStatement callableStatement;
            callableStatement = connection.prepareCall("{call getEnergyId(?, ?)}");
            callableStatement.setString(1, p_energy);
            callableStatement.registerOutParameter(2, Types.INTEGER); // Registro del parámetro de salida
            callableStatement.execute();

            int idReturned = callableStatement.getInt(2); 

            callableStatement.close();
            connection.close();

            return idReturned;

        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "error: " + e);
            return -1;
        }
    }

    
    public static int getSeverityId(String p_severity) {
        try {
            SysConexion con = new SysConexion();

            Connection connection; 
            connection = con.obtConexion();
            CallableStatement callableStatement;
            callableStatement = connection.prepareCall("{call getSeverityId(?, ?)}");
            callableStatement.setString(1, p_severity);
            callableStatement.registerOutParameter(2, Types.INTEGER); // Registro del parámetro de salida
            callableStatement.execute();

            int idReturned = callableStatement.getInt(2); 

            callableStatement.close();
            connection.close();

            return idReturned;

        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "error: " + e);
            return -1;
        }
    }

    
    public static int getColorId(String p_color) {
        try {
            SysConexion con = new SysConexion();

            Connection connection; 
            connection = con.obtConexion();
            CallableStatement callableStatement;
            callableStatement = connection.prepareCall("{call getColorId(?, ?)}");
            callableStatement.setString(1, p_color);
            callableStatement.registerOutParameter(2, Types.INTEGER); // Registro del parámetro de salida
            callableStatement.execute();

            int idReturned = callableStatement.getInt(2); 

            callableStatement.close();
            connection.close();

            return idReturned;

        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "error: " + e);
            return -1;
        }
    }

    
    public static int getPersonId(int p_ced) {
    try {
        SysConexion con = new SysConexion();

        Connection connection; 
        connection = con.obtConexion();
        CallableStatement callableStatement;
        callableStatement = connection.prepareCall("{call GetPersonIdByCedula(?, ?)}");  // Agregamos el segundo parámetro de salida
        callableStatement.setInt(1, p_ced);
        callableStatement.registerOutParameter(2, Types.INTEGER);  // Registro del parámetro de salida
        callableStatement.execute();

        int idReturned = callableStatement.getInt(2);  

        callableStatement.close();
        connection.close();
        
        return idReturned;

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        return -1;
    }
}


    
    public static int getPersonIdXMail(String p_email){
        try{
            SysConexion con = new SysConexion();

            Connection connection; 
            connection = con.obtConexion();
            CallableStatement callableStatement;
            callableStatement = connection.prepareCall("{? = call GetPersonIdByMail(?)}");
            callableStatement.registerOutParameter(1, Types.INTEGER);
            callableStatement.setString(2, p_email);
            callableStatement.execute();

            int idReturned = (int) callableStatement.getObject(1);
           
            callableStatement.close();
            connection.close();
            
            return idReturned;

        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "error: " + e);
            return -1;
        }
    }
    
    
    public static int getPetsXRescueId(int p_ced){
        try{
            SysConexion con = new SysConexion();

            Connection connection; 
            connection = con.obtConexion();
            CallableStatement callableStatement;
            callableStatement = connection.prepareCall("{? = call GetPetsXRescue(?)}");
            callableStatement.registerOutParameter(1, Types.INTEGER);
            callableStatement.setInt(2, p_ced);
            callableStatement.execute();

            int idReturned = (int) callableStatement.getObject(1);
           
            callableStatement.close();
            connection.close();
            
            return idReturned;

        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "error: " + e);
            return -1;
        }
    }
    
}
