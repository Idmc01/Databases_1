package control;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


    public class SysConexion {
        public Connection obtConexion() {
            try {
                // Establecer la información de conexión para MySQL
                String host = "jdbc:mysql://localhost:3306/Proyecto";
                String user = "root";
                String password = "admin";

                // Registrar el controlador JDBC de MySQL
                Class.forName("com.mysql.cj.jdbc.Driver");
                
                

                // Obtener la conexión
                Connection con = DriverManager.getConnection(host, user, password);

                return con;

            } catch (ClassNotFoundException e) {
                System.err.println("Error al cargar el controlador: " + e.getMessage());
                return null;
            } catch (SQLException e) {
                System.err.println("Error al establecer la conexión: " + e.getMessage());
                return null;
            }
        }
}

/*
public void conector() {
    // Reseteamos a null la conexion a la bd
    con = null;
    try {
        Class.forName(driver);
        // Nos conectamos a la bd
        con = (Connection) DriverManager.getConnection(url, user, pass);
        // Si la conexion fue exitosa mostramos un mensaje de conexion exitosa
        if (con != null) {
            jLabel1.setText("Conexion establecida");
        }
    } catch (ClassNotFoundException e) {
        jLabel1.setText("Error de Driver: " + e.getMessage());
    } catch (SQLException e) {
        jLabel1.setText("Error de conexion: " + e.getMessage());
    } finally {
        // Cerrar la conexión en el bloque finally
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            jLabel1.setText("Error al cerrar la conexion: " + e.getMessage());
        }
    }
}
*/