package model;

import control.SysConexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.CallableStatement;
import java.sql.Types;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 * Funciones para rellenar los combo boxes
 */
public class FillComboBox {

    public void FillAnimals(JComboBox combo) {
        SysConexion sysConexion = new SysConexion();

        try (Connection connection = sysConexion.obtConexion();
             CallableStatement callableStatement = connection.prepareCall("{? = CALL getAllAnimals()}")) {

            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.execute();
            String result = callableStatement.getString(1);

            if (result != null) {
                // Dividir la cadena por el carácter de guion y agregar cada animal al JComboBox
                String[] animalsArray = result.split("-");
                for (String animal : animalsArray) {
                    combo.addItem(animal);
                }
            } else {
                            }

        } catch (SQLException e) {
            System.err.println("Error al llenar el combo de animales: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

 

    public void FillRace(JComboBox combo) {
        SysConexion sysConexion = new SysConexion();

        try (Connection connection = sysConexion.obtConexion();
            CallableStatement callableStatement = connection.prepareCall("{? = CALL getAllRaces()}")) {

           callableStatement.registerOutParameter(1, Types.VARCHAR);
           callableStatement.execute();
           String result = callableStatement.getString(1);

           if (result != null) {
               // Dividir la cadena por el carácter de guion y agregar cada raza al JComboBox
               String[] racesArray = result.split("-");
               for (String race : racesArray) {
                   combo.addItem(race);
               }
           } else {
               
           }

       } catch (SQLException e) {
           System.err.println("Error al llenar el combo de razas: " + e.getMessage());
           JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
       }


    }

    public void FillColor(JComboBox combo) {
        SysConexion sysConexion = new SysConexion();

        try (Connection connection = sysConexion.obtConexion();
             CallableStatement callableStatement = connection.prepareCall("{? = CALL getAllColors()}")) {

            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.execute();
            String result = callableStatement.getString(1);

            if (result != null) {
                // Dividir la cadena por el carácter de guion y agregar cada color al JComboBox
                String[] colorsArray = result.split("-");
                for (String color : colorsArray) {
                    combo.addItem(color);
                }
            } else {
                
            }

        } catch (SQLException e) {
            System.err.println("Error al llenar el combo de colores: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }



    
    
    public void fillCountry(JComboBox<String> combo) {
    SysConexion sysConexion = new SysConexion();

    try (Connection connection = sysConexion.obtConexion();
         CallableStatement callableStatement = connection.prepareCall("{? = CALL getAllCountries()}")) {
        
        callableStatement.registerOutParameter(1, Types.VARCHAR);
        callableStatement.execute();
        String result = callableStatement.getString(1);
        
        // Dividir la cadena por el carácter de guion y agregar cada país al JComboBox
        String[] countriesArray = result.split("-");
        for (String country : countriesArray) {
            combo.addItem(country);
        }

    } catch (SQLException e) {
        System.err.println("Error al llenar el combo de países: " + e.getMessage());
        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
    }
}








 /*
            ResultSet rs;
            rs = callableStatement.getResultSet();

            if (hasResults) {
                
                    while (rs.next()) {
                        String countryName = callableStatement.getNString(1);
                        //String countryName = rs.getString("countryName");
                        System.out.println("Agregando país: " + countryName);
                        combo.addItem(countryName);
                    
                }
            }*/












    public void FillProvince(String selectedCountry, JComboBox<String> combo) {
    SysConexion sysConexion = new SysConexion();

    try (Connection connection = sysConexion.obtConexion()) {
        // Obtener el ID del país
        try (CallableStatement callableStatement1 = connection.prepareCall("{ call getCountryID(?, ?) }")) {
            callableStatement1.setString(1, selectedCountry);
            callableStatement1.registerOutParameter(2, Types.INTEGER);
            callableStatement1.execute();
            int countryId = callableStatement1.getInt(2);

            System.out.println("Country ID: " + countryId);

            // Obtener las provincias por ID de país
            try (CallableStatement callableStatement2 = connection.prepareCall("{ call GetProvincesByCountryID(?) }")) {
                callableStatement2.setInt(1, countryId);

                // Ejecutar el procedimiento almacenado
                boolean hasResults = callableStatement2.execute();

                // Recuperar el resultado de la tabla temporal
                while (hasResults) {
                    try (ResultSet rs = callableStatement2.getResultSet()) {
                        while (rs.next()) {
                            combo.addItem(rs.getString("provinceName"));
                        }
                    }

                    // Verificar si hay más conjuntos de resultados
                    hasResults = callableStatement2.getMoreResults();
                }
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error: " + e);
        e.printStackTrace();
    }
}










   public void FillCanton(String selectedProvince, JComboBox<String> combo) {
    SysConexion sysConexion = new SysConexion();

    try (Connection connection = sysConexion.obtConexion()) {
        // Obtener el ID de la provincia
        try (CallableStatement callableStatement1 = connection.prepareCall("{ call GetProvinceId(?, ?) }")) {
            callableStatement1.setString(1, selectedProvince);
            callableStatement1.registerOutParameter(2, Types.INTEGER);
            callableStatement1.execute();
            int provinceId = callableStatement1.getInt(2);

            // Obtener los cantones por ID de provincia
            try (CallableStatement callableStatement2 = connection.prepareCall("{ call GetCantonesByProvinceID(?) }")) {
                callableStatement2.setInt(1, provinceId);

                // Ejecutar el procedimiento almacenado
                ResultSet rs = callableStatement2.executeQuery();

                while (rs.next()) {
                    combo.addItem(rs.getString("CANTONNAME"));
                }
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error: " + e);
        e.printStackTrace();
    }
}


    public void FillDistrict(String selectedCanton, JComboBox<String> combo) {
    SysConexion sysConexion = new SysConexion();

    try (Connection connection = sysConexion.obtConexion()) {
        // Llamada al procedimiento para obtener el ID del cantón
        try (CallableStatement callableStatement1 = connection.prepareCall("{ CALL GetCantonId(?, ?) }")) {
            callableStatement1.setString(1, selectedCanton);
            callableStatement1.registerOutParameter(2, Types.INTEGER);

            // Ejecutar el procedimiento almacenado
            callableStatement1.execute();

            // Obtener el valor del parámetro de salida
            int cantonId = callableStatement1.getInt(2);

            // Obtener los distritos por ID de cantón
            try (CallableStatement callableStatement2 = connection.prepareCall("{ CALL GetDistrictsByCantonID(?) }")) {
                callableStatement2.setInt(1, cantonId);

                // Ejecutar el procedimiento almacenado
                ResultSet rs = callableStatement2.executeQuery();

                while (rs.next()) {
                    combo.addItem(rs.getString("DISTRICTNAME"));
                }
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error: " + e);
        e.printStackTrace();
    }
}



//arreglar


    public void FillStatus(JComboBox combo) {
        SysConexion sysConexion = new SysConexion();

        try (Connection connection = sysConexion.obtConexion();
             CallableStatement callableStatement = connection.prepareCall("{? = CALL getAllStatus()}")) {

            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.execute();
            String result = callableStatement.getString(1);

            // Verificar si el resultado no es nulo antes de dividir la cadena
            if (result != null) {
                // Dividir la cadena por el carácter de guion y agregar cada estado al JComboBox
                String[] statusArray = result.split("-");
                for (String status : statusArray) {
                    combo.addItem(status);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al llenar el combo de estados: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }



    public void FillEase(JComboBox combo) {
        SysConexion sysConexion = new SysConexion();

        try (Connection connection = sysConexion.obtConexion();
             CallableStatement callableStatement = connection.prepareCall("{? = CALL getAllEase()}")) {

            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.execute();
            String result = callableStatement.getString(1);

            // Verificar si el resultado no es nulo antes de dividir la cadena
            if (result != null) {
                // Dividir la cadena por el carácter de guion y agregar cada estado al JComboBox
                String[] easeArray = result.split("-");
                for (String ease : easeArray) {
                    combo.addItem(ease);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al llenar el combo de facilidad: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }


    public void FillEnergy(JComboBox combo) {
        SysConexion sysConexion = new SysConexion();

        try (Connection connection = sysConexion.obtConexion();
             CallableStatement callableStatement = connection.prepareCall("{? = CALL getAllEnergy()}")) {

            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.execute();
            String result = callableStatement.getString(1);

            // Verificar si el resultado no es nulo antes de dividir la cadena
            if (result != null) {
                // Dividir la cadena por el carácter de guion y agregar cada tipo de energía al JComboBox
                String[] energyArray = result.split("-");
                for (String energy : energyArray) {
                    combo.addItem(energy);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al llenar el combo de tipos de energía: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }


    public void FillSeverity(JComboBox combo) {
        SysConexion sysConexion = new SysConexion();

        try (Connection connection = sysConexion.obtConexion();
             CallableStatement callableStatement = connection.prepareCall("{? = CALL getAllSeverities()}")) {

            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.execute();
            String result = callableStatement.getString(1);

            // Verificar si el resultado no es nulo antes de dividir la cadena
            if (result != null) {
                // Dividir la cadena por el carácter de guion y agregar cada severidad al JComboBox
                String[] severitiesArray = result.split("-");
                for (String severity : severitiesArray) {
                    combo.addItem(severity);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al llenar el combo de severidades: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

}
